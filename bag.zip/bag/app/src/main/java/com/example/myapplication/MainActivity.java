package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.web3j.crypto.Credentials;
import org.web3j.protocol.admin.Admin;
import org.web3j.protocol.http.HttpService;

import java.math.BigInteger;

public class MainActivity extends AppCompatActivity {

    Button btn_query;
    Button btn_upload;
    Button btn_transaction;
    Button btn_my;
    public  static Bag token;
    public static Admin admin; //connect server
    public static Credentials credentials; //create account (private_key)
    Intent intent;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setid(); // setting component ID
        admin = Admin.build(new HttpService("http://140.120.55.86:7545"));
       // admin = Admin.build(new HttpService("http://10.0.2.2:8545"));
        //店家app
     // credentials=Credentials.create("1d30e945f6f097a2ef1d1b8843aa877d3fc1d34c514db6f6db11bfb540845755");
      //使用者app
        credentials=Credentials.create("b53e14b93441cf75b58c9eee7f6393c8a396b27dd0db1a949e6aa6d7ffdfd59b");

        loadContract();
        System.out.println(credentials.getAddress()); //0xbeA2d1b035618A35E09A196bc41d4b89Bedb0C4f
    }
    public void setid(){
        btn_query = findViewById(R.id.query_btn);
        btn_upload = findViewById(R.id.upload_btn);
        btn_transaction = findViewById(R.id.transaction_btn);
        btn_my = findViewById(R.id.btn_my);
        btn_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, Activity_upload.class);
                startActivity(intent);

            }
        });

        btn_transaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, Activity_transaction.class);
                startActivity(intent);
            }
        });

        btn_query.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, Activity_query.class);
                startActivity(intent);
            }
        });

        btn_my.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, Activity_my.class);
                startActivity(intent);
            }
        });
    }


    public  void loadContract(){
        BigInteger GAS_PRICE = BigInteger.valueOf(0);
        BigInteger GAS_LIMIT = BigInteger.valueOf(4_300_000);
        // //由0x2fe9645b5ab9f5ab03f5528add3bdede83f7cc55發佈
        String contractAddr = "0xd26d60fd3a1d62e91b450b64c6f728ba3bbe7884";
        token = Bag.load(
                contractAddr,
                admin,
                credentials,
                GAS_PRICE,
                GAS_LIMIT);

    }

}
