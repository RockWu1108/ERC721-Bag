package com.example.myapplication;

import io.reactivex.Flowable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import org.web3j.abi.EventEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Bool;
import org.web3j.abi.datatypes.DynamicArray;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.protocol.core.methods.request.EthFilter;
import org.web3j.protocol.core.methods.response.Log;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tuples.generated.Tuple5;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 4.3.0.
 */
public class Bag extends Contract {
    private static final String BINARY = "608060405234801561001057600080fd5b506116de806100206000396000f3fe6080604052600436106100c25760003560e01c8063a9fb2d811161007f578063c2fb09a811610059578063c2fb09a81461022a578063d24f4bf21461024a578063d7a85b8a14610277578063ffed5380146102a4576100c2565b8063a9fb2d81146101bd578063b28a9a66146101dd578063ba6de0321461020a576100c2565b80631ff29329146100c75780633ebfc934146100e957806370a08231146100fc5780637b865349146101325780638e0ad1cc1461015f578063920ffa2614610190575b600080fd5b3480156100d357600080fd5b506100e76100e2366004611203565b6102c4565b005b6100e76100f73660046110ac565b61057e565b34801561010857600080fd5b5061011c61011736600461104c565b61078a565b604051610129919061159b565b60405180910390f35b34801561013e57600080fd5b5061015261014d3660046111ce565b6107bb565b604051610129919061157c565b34801561016b57600080fd5b5061017f61017a3660046111ce565b6107e7565b6040516101299594939291906114fa565b34801561019c57600080fd5b506101b06101ab36600461118c565b610a54565b60405161012991906114ec565b3480156101c957600080fd5b506101526101d8366004611072565b610a89565b3480156101e957600080fd5b506101fd6101f83660046111ce565b610aa9565b604051610129919061155a565b34801561021657600080fd5b506100e7610225366004611114565b610b23565b34801561023657600080fd5b5061011c61024536600461104c565b610c0e565b34801561025657600080fd5b5061026a61026536600461104c565b610c20565b604051610129919061156b565b34801561028357600080fd5b5061029761029236600461115c565b610d0e565b604051610129919061158a565b3480156102b057600080fd5b5061011c6102bf36600461104c565b610dc2565b60006001600160a01b03166000856040516102df91906114d4565b908152604051908190036020019020546001600160a01b03161461030257600080fd5b60048460405161031291906114d4565b9081526040519081900360200190205460ff161561032f57600080fd5b3360008560405161034091906114d4565b908152604080516020928190038301812080546001600160a01b0319166001600160a01b0395909516949094179093553360009081526002835281812080546001908101909155600790935290812080549092019091559081906103a59087906114d4565b908152604051908190036020018120546001600160a01b031691506001906004906103d19088906114d4565b908152602001604051809103902060006101000a81548160ff0219169083151502179055506040518060a00160405280336001600160a01b031681526020018681526020018581526020018481526020018381525060058660405161043691906114d4565b90815260405160209181900382019020825181546001600160a01b0319166001600160a01b03909116178155828201518051919261047c92600185019290910190610dd4565b5060408201518051610498916002840191602090910190610dd4565b5060608201516003820155608082015180516104be916004840191602090910190610dd4565b509050506006856040516104d291906114d4565b908152604080519182900360209081018320805460018101825560009182528282200180546001600160a01b031916331790556001600160a01b0385168152600890915220906005906105269088906114d4565b9081526040516020918190038201902082546001808201808655600095865293909420918401805493946105759493909201929091600260001991831615610100029190910190911604610e52565b50505050505050565b60008083836040516105919291906114c7565b908152604051908190036020019020546001600160a01b039081169150851681146105bb57600080fd5b846001600160a01b0316816001600160a01b0316146105d957600080fd5b6001600160a01b0384166105ec57600080fd5b600483836040516105fe9291906114c7565b9081526040519081900360200190205460ff1661061a57600080fd5b836000848460405161062d9291906114c7565b908152604080516020928190038301812080546001600160a01b0319166001600160a01b039586161790558884166000908152600290935281832080546000190190559287168252902080546001019055849060059061069090869086906114c7565b90815260405190819003602001812080546001600160a01b03939093166001600160a01b0319909316929092179091556006906106d090859085906114c7565b9081526040805160209281900383019020805460018082018355600092835284832090910180546001600160a01b0319166001600160a01b038a1690811790915582526007845282822080548201905560088452918120805492830180825590825292902061074191018585610ec7565b50506107838584848080601f016020809104026020016040519081016040528093929190818152602001838380828437600092019190915250610b2392505050565b5050505050565b60006001600160a01b03821661079f57600080fd5b506001600160a01b031660009081526002602052604090205490565b60006004826040516107cd91906114d4565b9081526040519081900360200190205460ff169050919050565b60006060806000606060058660405161080091906114d4565b908152604051908190036020018120546001600160a01b0316906005906108289089906114d4565b908152602001604051809103902060010160058860405161084991906114d4565b908152602001604051809103902060020160058960405161086a91906114d4565b90815260200160405180910390206003015460058a60405161088c91906114d4565b9081526040805160209281900383018120865460026001821615610100026000190190911604601f8101859004850283018501909352828252600401929091869183018282801561091e5780601f106108f35761010080835404028352916020019161091e565b820191906000526020600020905b81548152906001019060200180831161090157829003601f168201915b5050865460408051602060026001851615610100026000190190941693909304601f8101849004840282018401909252818152959950889450925084019050828280156109ac5780601f10610981576101008083540402835291602001916109ac565b820191906000526020600020905b81548152906001019060200180831161098f57829003601f168201915b5050845460408051602060026001851615610100026000190190941693909304601f810184900484028201840190925281815295985086945092508401905082828015610a3a5780601f10610a0f57610100808354040283529160200191610a3a565b820191906000526020600020905b815481529060010190602001808311610a1d57829003601f168201915b505050505090509450945094509450945091939590929450565b6000808383604051610a679291906114c7565b908152604051908190036020019020546001600160a01b031690505b92915050565b600360209081526000928352604080842090915290825290205460ff1681565b6060600682604051610abb91906114d4565b9081526040805191829003602090810183208054808302850183019093528284529190830182828015610b1757602002820191906000526020600020905b81546001600160a01b03168152600190910190602001808311610af9575b50505050509050919050565b60005b6001600160a01b038316600090815260086020526040902054811015610c095781604051602001610b5791906114d4565b60408051601f1981840301815291815281516020928301206001600160a01b038616600090815260089093529120805483908110610b9157fe5b90600052602060002001604051602001610bab91906114e0565b604051602081830303815290604052805190602001201415610c01576001600160a01b0383166000908152600860205260409020805482908110610beb57fe5b906000526020600020016000610c019190610f35565b600101610b26565b505050565b60026020526000908152604090205481565b6001600160a01b0381166000908152600860209081526040808320805482518185028101850190935280835260609492939192909184015b82821015610d035760008481526020908190208301805460408051601f6002600019610100600187161502019094169390930492830185900485028101850190915281815292830182828015610cef5780601f10610cc457610100808354040283529160200191610cef565b820191906000526020600020905b815481529060010190602001808311610cd257829003601f168201915b505050505081526020019060010190610c58565b505050509050919050565b60086020528160005260406000208181548110610d2757fe5b600091825260209182902001805460408051601f60026000196101006001871615020190941693909304928301859004850281018501909152818152945090925090830182828015610dba5780601f10610d8f57610100808354040283529160200191610dba565b820191906000526020600020905b815481529060010190602001808311610d9d57829003601f168201915b505050505081565b60076020526000908152604090205481565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f10610e1557805160ff1916838001178555610e42565b82800160010185558215610e42579182015b82811115610e42578251825591602001919060010190610e27565b50610e4e929150610f7c565b5090565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f10610e8b5780548555610e42565b82800160010185558215610e4257600052602060002091601f016020900482015b82811115610e42578254825591600101919060010190610eac565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f10610f085782800160ff19823516178555610e42565b82800160010185558215610e42579182015b82811115610e42578235825591602001919060010190610f1a565b50805460018160011615610100020316600290046000825580601f10610f5b5750610f79565b601f016020900490600052602060002090810190610f799190610f7c565b50565b610f9691905b80821115610e4e5760008155600101610f82565b90565b8035610a838161167e565b60008083601f840112610fb657600080fd5b50813567ffffffffffffffff811115610fce57600080fd5b602083019150836001820283011115610fe657600080fd5b9250929050565b600082601f830112610ffe57600080fd5b813561101161100c826115d0565b6115a9565b9150808252602083016020830185838301111561102d57600080fd5b611038838284611638565b50505092915050565b8035610a8381611692565b60006020828403121561105e57600080fd5b600061106a8484610f99565b949350505050565b6000806040838503121561108557600080fd5b60006110918585610f99565b92505060206110a285828601610f99565b9150509250929050565b600080600080606085870312156110c257600080fd5b60006110ce8787610f99565b94505060206110df87828801610f99565b935050604085013567ffffffffffffffff8111156110fc57600080fd5b61110887828801610fa4565b95989497509550505050565b6000806040838503121561112757600080fd5b60006111338585610f99565b925050602083013567ffffffffffffffff81111561115057600080fd5b6110a285828601610fed565b6000806040838503121561116f57600080fd5b600061117b8585610f99565b92505060206110a285828601611041565b6000806020838503121561119f57600080fd5b823567ffffffffffffffff8111156111b657600080fd5b6111c285828601610fa4565b92509250509250929050565b6000602082840312156111e057600080fd5b813567ffffffffffffffff8111156111f757600080fd5b61106a84828501610fed565b6000806000806080858703121561121957600080fd5b843567ffffffffffffffff81111561123057600080fd5b61123c87828801610fed565b945050602085013567ffffffffffffffff81111561125957600080fd5b61126587828801610fed565b935050604061127687828801611041565b925050606085013567ffffffffffffffff81111561129357600080fd5b61129f87828801610fed565b91505092959194509250565b60006112b783836112d2565b505060200190565b60006112cb83836113d0565b9392505050565b6112db8161161c565b82525050565b60006112ec8261160a565b6112f6818561160e565b9350611301836115f8565b8060005b8381101561132f57815161131988826112ab565b9750611324836115f8565b925050600101611305565b509495945050505050565b60006113458261160a565b61134f818561160e565b935083602082028501611361856115f8565b8060005b8581101561139b578484038952815161137e85826112bf565b9450611389836115f8565b60209a909a0199925050600101611365565b5091979650505050505050565b6112db81611627565b60006113bd8385611617565b93506113ca838584611638565b50500190565b60006113db8261160a565b6113e5818561160e565b93506113f5818560208601611644565b6113fe81611674565b9093019392505050565b60006114138261160a565b61141d8185611617565b935061142d818560208601611644565b9290920192915050565b6000815460018116600081146114545760018114611477576114b6565b607f60028304166114658187611617565b60ff19841681529550850192506114b6565b600282046114858187611617565b9550611490856115fe565b60005b828110156114af57815488820152600190910190602001611493565b5050850192505b505092915050565b6112db81610f96565b600061106a8284866113b1565b60006112cb8284611408565b60006112cb8284611437565b60208101610a8382846112d2565b60a0810161150882886112d2565b818103602083015261151a81876113d0565b9050818103604083015261152e81866113d0565b905061153d60608301856114be565b818103608083015261154f81846113d0565b979650505050505050565b602080825281016112cb81846112e1565b602080825281016112cb818461133a565b60208101610a8382846113a8565b602080825281016112cb81846113d0565b60208101610a8382846114be565b60405181810167ffffffffffffffff811182821017156115c857600080fd5b604052919050565b600067ffffffffffffffff8211156115e757600080fd5b506020601f91909101601f19160190565b60200190565b60009081526020902090565b5190565b90815260200190565b919050565b6000610a838261162c565b151590565b6001600160a01b031690565b82818337506000910152565b60005b8381101561165f578181015183820152602001611647565b8381111561166e576000848401525b50505050565b601f01601f191690565b6116878161161c565b8114610f7957600080fd5b61168781610f9656fea365627a7a72305820018456de80b6911ce66dd4bab91bb6609dffb659b96aeeb11c8e0d3f0f5a72c26c6578706572696d656e74616cf564736f6c63430005090040";

    public static final String FUNC_ADDTOKEN = "addToken";

    public static final String FUNC_TRANSFERFROM = "transferFrom";

    public static final String FUNC_BALANCEOF = "balanceOf";

    public static final String FUNC_GETEXIST = "getExist";

    public static final String FUNC_GETTOKENINFO = "getTokenInfo";

    public static final String FUNC_OWNEROF = "ownerOf";

    public static final String FUNC_OPERATORAPPROVAL = "operatorApproval";

    public static final String FUNC_GETTOKENLIST = "getTokenlist";

    public static final String FUNC_DELETE_ELEMETE = "delete_elemete";

    public static final String FUNC_OWNERTOKENCOUNT = "ownerTokenCount";

    public static final String FUNC_GETALLREAD = "getallread";

    public static final String FUNC_ALLREAD = "allread";

    public static final String FUNC_HISTORYOWNERTOKENCOUNT = "historyownerTokenCount";

    public static final Event TRANSFER_EVENT = new Event("Transfer", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Address>(true) {}, new TypeReference<Uint256>(true) {}));
    ;

    public static final Event APPROVAL_EVENT = new Event("Approval", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Address>(true) {}, new TypeReference<Uint256>(true) {}));
    ;

    public static final Event APPROVALFORALL_EVENT = new Event("ApprovalForAll", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Address>(true) {}, new TypeReference<Bool>() {}));
    ;

    @Deprecated
    protected Bag(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected Bag(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, credentials, contractGasProvider);
    }

    @Deprecated
    protected Bag(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    protected Bag(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public RemoteCall<TransactionReceipt> addToken(String _tokenId, String _bag_name, BigInteger _time, String _material) {
        final Function function = new Function(
                FUNC_ADDTOKEN, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_tokenId), 
                new org.web3j.abi.datatypes.Utf8String(_bag_name), 
                new org.web3j.abi.datatypes.generated.Uint256(_time), 
                new org.web3j.abi.datatypes.Utf8String(_material)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<TransactionReceipt> transferFrom(String _from, String _to, String _tokenId, BigInteger weiValue) {
        final Function function = new Function(
                FUNC_TRANSFERFROM, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(_from), 
                new org.web3j.abi.datatypes.Address(_to), 
                new org.web3j.abi.datatypes.Utf8String(_tokenId)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function, weiValue);
    }

    public RemoteCall<BigInteger> balanceOf(String _owner) {
        final Function function = new Function(FUNC_BALANCEOF, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(_owner)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<Boolean> getExist(String _tokenId) {
        final Function function = new Function(FUNC_GETEXIST, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_tokenId)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<Tuple5<String, String, String, BigInteger, String>> getTokenInfo(String TokenId) {
        final Function function = new Function(FUNC_GETTOKENINFO, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(TokenId)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}));
        return new RemoteCall<Tuple5<String, String, String, BigInteger, String>>(
                new Callable<Tuple5<String, String, String, BigInteger, String>>() {
                    @Override
                    public Tuple5<String, String, String, BigInteger, String> call() throws Exception {
                        List<Type> results = executeCallMultipleValueReturn(function);
                        return new Tuple5<String, String, String, BigInteger, String>(
                                (String) results.get(0).getValue(), 
                                (String) results.get(1).getValue(), 
                                (String) results.get(2).getValue(), 
                                (BigInteger) results.get(3).getValue(), 
                                (String) results.get(4).getValue());
                    }
                });
    }

    public RemoteCall<String> ownerOf(String _tokenId) {
        final Function function = new Function(FUNC_OWNEROF, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_tokenId)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<Boolean> operatorApproval(String param0, String param1) {
        final Function function = new Function(FUNC_OPERATORAPPROVAL, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(param0), 
                new org.web3j.abi.datatypes.Address(param1)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<List> getTokenlist(String _tokenId) {
        final Function function = new Function(FUNC_GETTOKENLIST, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_tokenId)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<DynamicArray<Address>>() {}));
        return new RemoteCall<List>(
                new Callable<List>() {
                    @Override
                    @SuppressWarnings("unchecked")
                    public List call() throws Exception {
                        List<Type> result = (List<Type>) executeCallSingleValueReturn(function, List.class);
                        return convertToNative(result);
                    }
                });
    }

    public RemoteCall<TransactionReceipt> delete_elemete(String owner, String _tokenId) {
        final Function function = new Function(
                FUNC_DELETE_ELEMETE, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(owner), 
                new org.web3j.abi.datatypes.Utf8String(_tokenId)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<BigInteger> ownerTokenCount(String param0) {
        final Function function = new Function(FUNC_OWNERTOKENCOUNT, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(param0)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<List> getallread(String _owner) {
        final Function function = new Function(FUNC_GETALLREAD, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(_owner)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<DynamicArray<Utf8String>>() {}));
        return new RemoteCall<List>(
                new Callable<List>() {
                    @Override
                    @SuppressWarnings("unchecked")
                    public List call() throws Exception {
                        List<Type> result = (List<Type>) executeCallSingleValueReturn(function, List.class);
                        return convertToNative(result);
                    }
                });
    }

    public RemoteCall<String> allread(String param0, BigInteger param1) {
        final Function function = new Function(FUNC_ALLREAD, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(param0), 
                new org.web3j.abi.datatypes.generated.Uint256(param1)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<BigInteger> historyownerTokenCount(String param0) {
        final Function function = new Function(FUNC_HISTORYOWNERTOKENCOUNT, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(param0)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public List<TransferEventResponse> getTransferEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(TRANSFER_EVENT, transactionReceipt);
        ArrayList<TransferEventResponse> responses = new ArrayList<TransferEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            TransferEventResponse typedResponse = new TransferEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse._from = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse._to = (String) eventValues.getIndexedValues().get(1).getValue();
            typedResponse._tokenId = (BigInteger) eventValues.getIndexedValues().get(2).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public Flowable<TransferEventResponse> transferEventFlowable(EthFilter filter) {
        return web3j.ethLogFlowable(filter).map(new io.reactivex.functions.Function<Log, TransferEventResponse>() {
            @Override
            public TransferEventResponse apply(Log log) {
                Contract.EventValuesWithLog eventValues = extractEventParametersWithLog(TRANSFER_EVENT, log);
                TransferEventResponse typedResponse = new TransferEventResponse();
                typedResponse.log = log;
                typedResponse._from = (String) eventValues.getIndexedValues().get(0).getValue();
                typedResponse._to = (String) eventValues.getIndexedValues().get(1).getValue();
                typedResponse._tokenId = (BigInteger) eventValues.getIndexedValues().get(2).getValue();
                return typedResponse;
            }
        });
    }

    public Flowable<TransferEventResponse> transferEventFlowable(DefaultBlockParameter startBlock, DefaultBlockParameter endBlock) {
        EthFilter filter = new EthFilter(startBlock, endBlock, getContractAddress());
        filter.addSingleTopic(EventEncoder.encode(TRANSFER_EVENT));
        return transferEventFlowable(filter);
    }

    public List<ApprovalEventResponse> getApprovalEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(APPROVAL_EVENT, transactionReceipt);
        ArrayList<ApprovalEventResponse> responses = new ArrayList<ApprovalEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            ApprovalEventResponse typedResponse = new ApprovalEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse._owner = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse._approved = (String) eventValues.getIndexedValues().get(1).getValue();
            typedResponse._tokenId = (BigInteger) eventValues.getIndexedValues().get(2).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public Flowable<ApprovalEventResponse> approvalEventFlowable(EthFilter filter) {
        return web3j.ethLogFlowable(filter).map(new io.reactivex.functions.Function<Log, ApprovalEventResponse>() {
            @Override
            public ApprovalEventResponse apply(Log log) {
                Contract.EventValuesWithLog eventValues = extractEventParametersWithLog(APPROVAL_EVENT, log);
                ApprovalEventResponse typedResponse = new ApprovalEventResponse();
                typedResponse.log = log;
                typedResponse._owner = (String) eventValues.getIndexedValues().get(0).getValue();
                typedResponse._approved = (String) eventValues.getIndexedValues().get(1).getValue();
                typedResponse._tokenId = (BigInteger) eventValues.getIndexedValues().get(2).getValue();
                return typedResponse;
            }
        });
    }

    public Flowable<ApprovalEventResponse> approvalEventFlowable(DefaultBlockParameter startBlock, DefaultBlockParameter endBlock) {
        EthFilter filter = new EthFilter(startBlock, endBlock, getContractAddress());
        filter.addSingleTopic(EventEncoder.encode(APPROVAL_EVENT));
        return approvalEventFlowable(filter);
    }

    public List<ApprovalForAllEventResponse> getApprovalForAllEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(APPROVALFORALL_EVENT, transactionReceipt);
        ArrayList<ApprovalForAllEventResponse> responses = new ArrayList<ApprovalForAllEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            ApprovalForAllEventResponse typedResponse = new ApprovalForAllEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse._owner = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse._operator = (String) eventValues.getIndexedValues().get(1).getValue();
            typedResponse._approved = (Boolean) eventValues.getNonIndexedValues().get(0).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public Flowable<ApprovalForAllEventResponse> approvalForAllEventFlowable(EthFilter filter) {
        return web3j.ethLogFlowable(filter).map(new io.reactivex.functions.Function<Log, ApprovalForAllEventResponse>() {
            @Override
            public ApprovalForAllEventResponse apply(Log log) {
                Contract.EventValuesWithLog eventValues = extractEventParametersWithLog(APPROVALFORALL_EVENT, log);
                ApprovalForAllEventResponse typedResponse = new ApprovalForAllEventResponse();
                typedResponse.log = log;
                typedResponse._owner = (String) eventValues.getIndexedValues().get(0).getValue();
                typedResponse._operator = (String) eventValues.getIndexedValues().get(1).getValue();
                typedResponse._approved = (Boolean) eventValues.getNonIndexedValues().get(0).getValue();
                return typedResponse;
            }
        });
    }

    public Flowable<ApprovalForAllEventResponse> approvalForAllEventFlowable(DefaultBlockParameter startBlock, DefaultBlockParameter endBlock) {
        EthFilter filter = new EthFilter(startBlock, endBlock, getContractAddress());
        filter.addSingleTopic(EventEncoder.encode(APPROVALFORALL_EVENT));
        return approvalForAllEventFlowable(filter);
    }

    @Deprecated
    public static Bag load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new Bag(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    @Deprecated
    public static Bag load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new Bag(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public static Bag load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new Bag(contractAddress, web3j, credentials, contractGasProvider);
    }

    public static Bag load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new Bag(contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static RemoteCall<Bag> deploy(Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Bag.class, web3j, credentials, contractGasProvider, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Bag> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Bag.class, web3j, credentials, gasPrice, gasLimit, BINARY, "");
    }

    public static RemoteCall<Bag> deploy(Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Bag.class, web3j, transactionManager, contractGasProvider, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Bag> deploy(Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Bag.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, "");
    }

    public static class TransferEventResponse {
        public Log log;

        public String _from;

        public String _to;

        public BigInteger _tokenId;
    }

    public static class ApprovalEventResponse {
        public Log log;

        public String _owner;

        public String _approved;

        public BigInteger _tokenId;
    }

    public static class ApprovalForAllEventResponse {
        public Log log;

        public String _owner;

        public String _operator;

        public Boolean _approved;
    }
}
