package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class Adapter_my extends BaseAdapter {
    public LayoutInflater inflater;
    List data;
    String array[][];
    static class ViewHolder{
        TextView _id ;
        TextView _name ;
        TextView _time ;
        TextView _material;
    }


    public Adapter_my(LayoutInflater inflater, List list,String array[][]) {
        this.inflater =inflater;
        this.data=list;
        this.array=array;
        System.out.println(list.size());
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {


        ViewHolder holder;
        if(convertView==null){
            convertView= inflater.inflate(R.layout.list_item,null);
            holder=new ViewHolder();
            holder._id = convertView.findViewById(R.id.item_id);
            holder._name = convertView.findViewById(R.id.item_draw_name);
            holder._time =convertView.findViewById(R.id.item_time);
            holder._material = convertView.findViewById(R.id.item_material);

            holder._id.setText("ID:\t"+array[i][0]);
            holder._name.setText("包包名：\t"+array[i][1]);
            holder._time.setText("生產時間：\t"+array[i][2]+"年");
            holder._material.setText("材質：\t"+array[i][3]);



        }
        else{

            holder = (ViewHolder) convertView.getTag();
        }

        return convertView;
    }
}
