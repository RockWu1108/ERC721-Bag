package com.example.myapplication;

import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.NfcA;
import android.nfc.tech.TagTechnology;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.util.MyNfcTag;

import org.web3j.tuples.generated.Tuple5;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


public class Activity_query extends AppCompatActivity {
    TextView text_quety;
    Button query_btn;
    ListView listView;

    String  id;
    String address ;
    String tag_id ;
    String name ;
    BigInteger time ;
    String material;

    List arrayList = Collections.synchronizedList(new ArrayList());
    List info =new ArrayList();
    ArrayAdapter<String> adapter;

    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_query);
        setID();
        query_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                info.clear();
                query();
            }
        });
        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,
                info);

        if (isNFCReady()) {
            startActivity(new Intent(this, Activity_query.class));
            findTag();
//            readNfcTag();
        }



    }

    public void setID() {
        text_quety = findViewById(R.id.edt_quety);
        query_btn = findViewById(R.id.query_btn);
        listView = findViewById(R.id.listview);

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
    }

    public void query() {


         new Thread(new Runnable() {
            @Override
            public void run() {
                id = text_quety.getText().toString();
                try {
                    if(MainActivity.token.getExist(id).send()) {



                        Tuple5<String, String, String, BigInteger, String> A = MainActivity.token.getTokenInfo(id).send();
                        address = A.getValue1();
                        tag_id =  A.getValue2();
                        name = A.getValue3();
                        time =  A.getValue4();
                        material = A.getValue5();
                        arrayList=(MainActivity.token.getTokenlist(id).send()) ;

                        //更新UI及產生Dialog畫面
                        Activity_query.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                LayoutInflater inflater = LayoutInflater.from(Activity_query.this);
                                final View v = inflater.inflate(R.layout.query_dialog, null);
                                TextView query_address = v.findViewById(R.id.dialog_address);
                                TextView query_id = v.findViewById(R.id.dialog_id);
                                TextView query_drawer_name = v.findViewById(R.id.dialog_draw_name);
                                TextView query_time = v.findViewById(R.id.dialog_time);
                                TextView query_material = v.findViewById(R.id.dialog_material);
                                query_address.setText("擁有者地址：" + address);
                                query_id.setText("ID :" + tag_id);
                                query_drawer_name.setText("包包名：" + name);
                                query_time.setText("生產時間：" + time+"年");
                                query_material.setText("材質：" + material);

                                for(int i =0; i<arrayList.size();i++){
                                    info.add(arrayList.get(i));
                                }

                                listView.setAdapter(adapter);
                                if(v.getParent()!=null){
                                    ((ViewGroup)v.getParent()).removeView(v); // <- fix

                                }

                                new AlertDialog.Builder(Activity_query.this)
                                        .setView(v)
                                        .show();
                            }
                        });

                    }
                    else{

                        Activity_query.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                new AlertDialog.Builder(Activity_query.this)
                                        .setTitle("Error Message")
                                        .setMessage("該ID未記錄於區塊鏈中！！！")
                                        .show();
                            }
                        });


                    }
                } catch (Exception E) {
                    E.printStackTrace();
                }

            }

        }).start();

    }
    @Override
    protected void onStart() {
        super.onStart();

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
        IntentFilter ndefDetected = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);

        try {
            ndefDetected.addDataType("text/plain");
        } catch (IntentFilter.MalformedMimeTypeException e) {
            Log.e(this.getClass().getName(), "MalformedMimeTypeException :" + e.getMessage());
        }
        // gNdefExchangeFilters = new IntentFilter[]{ ndefDetected };
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();

        if (nfcAdapter != null)
            nfcAdapter.disableForegroundDispatch(this);
    }

    /*
     * 判斷裝置是否有支援/打開NFC功能
     */
    private boolean isNFCReady() {
        if (nfcAdapter == null) {
            Toast.makeText(this, "此裝置不支援NFC", Toast.LENGTH_LONG);
            return false;
        }
        if (nfcAdapter != null && !nfcAdapter.isEnabled()) {
            Toast.makeText(this, "請打開裝置的NFC功能", Toast.LENGTH_LONG);
            return false;
        }

        return true;
    }

    private void findTag() {
        Intent intent = getIntent();
        Log.e("TAG",NfcAdapter.ACTION_TAG_DISCOVERED+" "+intent.getAction());
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction())) {
            Toast.makeText(this, "ACTION_TAG_DISCOVERED", Toast.LENGTH_SHORT).show();

            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);

            if (tag == null) {
//                tag_view.setText("沒有偵測到NFC Tag");
            } else {
                MyNfcTag myTag = new MyNfcTag(tag);
                text_quety.setText(myTag.getTagid());
                Log.e("taginfo",myTag.getTagid());
//                tag_view.setText(myTag.getTagInfo());

            }
        } else {
            Toast.makeText(this, "ACTION_TAG_DISCOVERED NOT READY", Toast.LENGTH_SHORT).show();
        }

    }

    private void readNfcTag() {
        String ndefText = "";
        Intent intent = getIntent();
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);

        if (tag != null) {
            MyNfcTag myTag = new MyNfcTag(tag);
            TagTechnology object = myTag.getTagByFirstTech();

            if (object instanceof NfcA) {
                NfcA myNfcA = (NfcA) object;

//                ndef_view.setText("NfcA tag max transceive length is : " + myNfcA.getMaxTransceiveLength() + "\n");
            } else {
//                ndef_view.setText("尚未實作相關讀取功能");
            }

        }


    }

    private String parseTextRecord(NdefRecord ndefRecord) {

        if (ndefRecord.getTnf() != NdefRecord.TNF_WELL_KNOWN) {
            return null;
        }

        if (!Arrays.equals(ndefRecord.getType(), NdefRecord.RTD_TEXT)) {
            return null;
        }

        try {

            byte[] payload = ndefRecord.getPayload();
            String textEncoding = ((payload[0] & 0x80) == 0) ? "UTF-8" : "UTF-16";

            int languageCodeLength = payload[0] & 0x3f;

            String languageCode = new String(payload, 1, languageCodeLength, "US-ASCII");
            String textRecord = new String(payload, languageCodeLength + 1, payload.length - languageCodeLength - 1, textEncoding);

            return textRecord;
        } catch (Exception e) {
            throw new IllegalArgumentException();
        }
    }

}
