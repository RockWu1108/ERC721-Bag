package com.example.myapplication;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.NfcA;
import android.nfc.tech.TagTechnology;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.util.MyNfcTag;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tuples.generated.Tuple5;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import static android.widget.Toast.makeText;


public class Activity_transaction extends AppCompatActivity {
    TextView text_id;
    EditText edt_to;
    EditText edt_from;
    Button btn_trn;
    Button btn_qrcode;
    Button btn_scanner;
    EditText edt_value;

    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;

    private IntentIntegrator scanIntegrator;
    Dialog mydialog;
    ImageView qrcode_dialog_img;
    AlertDialog dialog;
    AlertDialog.Builder login_dialog;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);
        setid();

        if (isNFCReady()) {
            startActivity(new Intent(this, Activity_transaction.class));
            findTag();
//            readNfcTag();
        }

    }

    public void setid() {
        text_id = findViewById(R.id.text_id);
        edt_to = findViewById(R.id.edt_to);
        edt_from =findViewById(R.id.edt_from);
        btn_trn = findViewById(R.id.btn_trn);
        btn_qrcode = findViewById(R.id.btn_qrcode);
        btn_scanner = findViewById(R.id.btn_scanner);

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

        //AlertDialog 元件設定
        LayoutInflater inflater = LayoutInflater.from(Activity_transaction.this);
        final View v = inflater.inflate(R.layout.transaction_dialog, null);
        TextView query_address = v.findViewById(R.id.dialog_address);
        TextView query_id = v.findViewById(R.id.dialog_id);
        TextView query_drawer_name = v.findViewById(R.id.dialog_draw_name);
        TextView query_drawer = v.findViewById(R.id.dialog_drawer);
        TextView query_time = v.findViewById(R.id.dialog_time);
        TextView query_long = v.findViewById(R.id.dialog_long);
        TextView query_width = v.findViewById(R.id.dialog_material);
        Button dialog_btn_submit = v.findViewById(R.id.dialog_btn_submit);
        Button dialog_btn_cancel = v.findViewById(R.id.dialog_btn_cancel);

        //交易事件
        btn_trn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            String owner = MainActivity.token.ownerOf(text_id.getText().toString()).send();
//                            if (MainActivity.token.tokenExists(BigInteger.valueOf(Integer.parseInt(AB))).send()) {
                            if(MainActivity.credentials.getAddress().equals(owner)){
                                Tuple5<String, String, String, BigInteger, String> A = MainActivity.token.getTokenInfo(text_id.getText().toString()).send();
                                String address =A.getValue1();
                                String tag_id = A.getValue2();
                                String name = A.getValue3();
                                BigInteger time = A.getValue4() ;
                                String material = A.getValue5();

                                //刷新UI畫面
                                Activity_transaction.this.runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {

                                        //避免有重疊view
                                        if(v.getParent()!=null){
                                            ((ViewGroup)v.getParent()).removeView(v); // <- fix
                                        }
                                        login_dialog = new AlertDialog.Builder(Activity_transaction.this);
                                        login_dialog.setView(v);
                                        dialog=login_dialog.show();
                                        query_address.setText("擁有者地址：" + address);
                                        query_drawer_name.setText("畫名：" + name);
                                        query_id.setText("ID :" + tag_id);
                                        query_time.setText("生產時間：" + time);
                                        query_long.setText("材質：" + material);


                                        //Dialog取消按鈕
                                        dialog_btn_cancel.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                System.out.println("取消");
                                                dialog.dismiss();
                                            }
                                        });

                                        //Dialog確定按鈕
                                        dialog_btn_submit.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {

//                                                BigInteger GAS_PRICE = BigInteger.valueOf(0);
//                                                BigInteger GAS_LIMIT = BigInteger.valueOf(4_300_000);
                                                //  String address_to = "0x5b02d2123a00c46ea22047c3142BE20B2c6aab65";

                                                new Thread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        try {
//                                                            System.out.println("Address:"+MainActivity.credentials.getAddress());
//                                                            EthGetTransactionCount ethGetTransactionCount =MainActivity.admin.ethGetTransactionCount(
//                                                                    MainActivity.credentials.getAddress(), DefaultBlockParameterName.LATEST).sendAsync().get();
//
//
//                                                            BigInteger nonce = ethGetTransactionCount.getTransactionCount();
//                                                            //创建交易，这里是转0.5个以太币
//                                                            BigInteger value = Convert.toWei(edt_value.getText().toString(), Convert.Unit.ETHER).toBigInteger();
//                                                            RawTransaction rawTransaction = RawTransaction.createEtherTransaction(
//                                                                    nonce, GAS_PRICE, GAS_LIMIT, edt_to.getText().toString(), value);
//
//                                                            //交易簽章
//                                                            byte[] signedMessage = TransactionEncoder.signMessage(rawTransaction, MainActivity.credentials);
//                                                            String hexValue = Numeric.toHexString(signedMessage);
//
//                                                            //发送交易
//                                                            EthSendTransaction ethSendTransaction =MainActivity.admin.ethSendRawTransaction(hexValue).sendAsync().get();
//                                                            String transactionHash = ethSendTransaction.getTransactionHash();
//                                                            System.out.println("txhash:"+transactionHash);
                                                    //-----------------------------------------上方為乙太坊轉帳----------------------------------

                                                        TransactionReceipt event= MainActivity.token.transferFrom(MainActivity.credentials.getAddress(),edt_to.getText().toString(),text_id.getText().toString(), BigInteger.valueOf(0)).send();


                                                        dialog.dismiss();
                                                        if(!event.getTransactionHash().equals(null)) {
                                                            Activity_transaction.this.runOnUiThread(new Runnable() {
                                                                @Override
                                                                public void run() {
                                                                    new AlertDialog.Builder(Activity_transaction.this)
                                                                            .setTitle("交易成功! ! !")
                                                                            .setMessage("Success！！！")
                                                                            .show();
                                                                        text_id.setText("");
                                                                        edt_to.setText("");
                                                                }
                                                            });

                                                        }
                                                        }  catch (InterruptedException e) {
                                                            e.printStackTrace();
                                                        } catch (ExecutionException e) {
                                                            e.printStackTrace();
                                                        } catch (Exception e) {
                                                            e.printStackTrace();
                                                        }
                                                    }
                                                }).start();

                                            }
                                        });
                                    }
                                });

                            }


                            else {
                                Activity_transaction.this.runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        new AlertDialog.Builder(Activity_transaction.this)
                                                .setTitle("Error Transaction ! ! !")
                                                .setMessage("您不是畫作擁有者！！！")
                                                .show();
                                    }
                                });

                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                }).start();

            }
        });

        //開啟相機掃描
        btn_scanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scanIntegrator = new IntentIntegrator(Activity_transaction.this);
                scanIntegrator.setPrompt("請掃描");
                scanIntegrator.setTimeout(300000);
                scanIntegrator.initiateScan();
            }
        });

        //產生自己錢包QR_CODE
        btn_qrcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                create_qrcode();
            }
        });

        //EditText監聽
        text_id.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {


            }

            @Override
            public void afterTextChanged(Editable editable) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(1000);
                            if(!editable.toString().equals("")) {
                                if (MainActivity.token.getExist(editable.toString()).send()) {
                                    if(MainActivity.token.ownerOf(editable.toString()).send().equals(MainActivity.credentials.getAddress())) {
                                        String add = MainActivity.token.ownerOf(editable.toString()).send();
                                        System.out.println(add);
                                        Activity_transaction.this.runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                new AlertDialog.Builder(Activity_transaction.this)
                                                        .setTitle("Verification Success")
                                                        .setMessage("您有畫作所有權！！！")
                                                        .show();
                                                edt_from.setText(add);
                                                edt_from.setEnabled(false);
                                            }
                                        });
                                    }
                                    else{
                                        Activity_transaction.this.runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                new AlertDialog.Builder(Activity_transaction.this)
                                                        .setTitle("Error Message")
                                                        .setMessage("您沒有此畫作擁有權！！！")
                                                        .show();
                                            }
                                        });

                                    }
                                }

                                else {
                                    Activity_transaction.this.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {

                                            new AlertDialog.Builder(Activity_transaction.this)
                                                    .setTitle("Error Message")
                                                    .setMessage("該ID未記錄於區塊鏈中！！！")
                                                    .show();
                                        }
                                    });
                                }
                            }

                            else{
                                Activity_transaction.this.runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        edt_from.setText("");
                                    }
                                });


                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });

    }



    //QRcode掃描結果
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        IntentResult scanningResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
        if (scanningResult != null) {
            if (scanningResult.getContents() != null) {
                String scanContent = scanningResult.getContents();
                if (!scanContent.equals("")) {
                    // Toast.makeText(getApplicationContext(), "掃描內容: " + scanContent.toString(), Toast.LENGTH_LONG).show();
                    edt_to.setText(scanContent.toString());
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, intent);
            makeText(getApplicationContext(), "發生錯誤", Toast.LENGTH_LONG).show();
        }
    }

    //產生錢包地址QRcode
    public void create_qrcode(){
        BarcodeEncoder encoder = new BarcodeEncoder();
        try {
            Map hints = new EnumMap(EncodeHintType.class);
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            Bitmap bit = encoder.encodeBitmap(MainActivity.credentials.getAddress(), BarcodeFormat.QR_CODE, 500, 500,hints);
            //img_wallet_qrcode.setImageBitmap(bit);
            qrcode_image(bit);

        } catch (WriterException e) {
            e.printStackTrace();
        }
    }

    //產生qrcode_dialog
    private void qrcode_image(Bitmap bit){
        mydialog = new Dialog(Activity_transaction.this);
        mydialog.setContentView(R.layout.qrcode_dialog_image);
        qrcode_dialog_img = mydialog.findViewById(R.id.qrcode_image);
        qrcode_dialog_img.setImageBitmap(bit);
        mydialog.show();
    }

    @Override
    protected void onStart() {
        super.onStart();

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
        IntentFilter ndefDetected = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);

        try {
            ndefDetected.addDataType("text/plain");
        } catch (IntentFilter.MalformedMimeTypeException e) {
            Log.e(this.getClass().getName(), "MalformedMimeTypeException :" + e.getMessage());
        }
        // gNdefExchangeFilters = new IntentFilter[]{ ndefDetected };
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();

        if (nfcAdapter != null)
            nfcAdapter.disableForegroundDispatch(this);
    }

    /*
     * 判斷裝置是否有支援/打開NFC功能
     */
    private boolean isNFCReady() {
        if (nfcAdapter == null) {
            Toast.makeText(this, "此裝置不支援NFC", Toast.LENGTH_LONG);
            return false;
        }
        if (nfcAdapter != null && !nfcAdapter.isEnabled()) {
            Toast.makeText(this, "請打開裝置的NFC功能", Toast.LENGTH_LONG);
            return false;
        }

        return true;
    }

    private void findTag() {
        Intent intent = getIntent();
        Log.e("TAG",NfcAdapter.ACTION_TAG_DISCOVERED+" "+intent.getAction());
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction())) {
            Toast.makeText(this, "ACTION_TAG_DISCOVERED", Toast.LENGTH_SHORT).show();

            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);

            if (tag == null) {
//                tag_view.setText("沒有偵測到NFC Tag");
            } else {
                MyNfcTag myTag = new MyNfcTag(tag);
//                tag_view.setText(myTag.getTagInfo());
                text_id.setText(myTag.getTagid());
                Log.e("tagid",myTag.getTagid());

            }
        } else {
            Toast.makeText(this, "ACTION_TAG_DISCOVERED NOT READY", Toast.LENGTH_SHORT).show();
        }

    }

    private void readNfcTag() {
        String ndefText = "";
        Intent intent = getIntent();
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);

        if (tag != null) {
            MyNfcTag myTag = new MyNfcTag(tag);
            TagTechnology object = myTag.getTagByFirstTech();

            if (object instanceof NfcA) {
                NfcA myNfcA = (NfcA) object;
//                ndef_view.setText("NfcA tag max transceive length is : " + myNfcA.getMaxTransceiveLength() + "\n");
            } else {
//                ndef_view.setText("尚未實作相關讀取功能");
            }

        }


    }

    private String parseTextRecord(NdefRecord ndefRecord) {

        if (ndefRecord.getTnf() != NdefRecord.TNF_WELL_KNOWN) {
            return null;
        }

        if (!Arrays.equals(ndefRecord.getType(), NdefRecord.RTD_TEXT)) {
            return null;
        }

        try {

            byte[] payload = ndefRecord.getPayload();
            String textEncoding = ((payload[0] & 0x80) == 0) ? "UTF-8" : "UTF-16";

            int languageCodeLength = payload[0] & 0x3f;

            String languageCode = new String(payload, 1, languageCodeLength, "US-ASCII");
            String textRecord = new String(payload, languageCodeLength + 1, payload.length - languageCodeLength - 1, textEncoding);

            return textRecord;
        } catch (Exception e) {
            throw new IllegalArgumentException();
        }
    }
}
