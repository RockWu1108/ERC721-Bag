package com.example.myapplication;

import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

//import org.web3j.protocol.core.methods.response.Log;
import org.web3j.protocol.core.methods.response.TransactionReceipt;

import java.math.BigInteger;
import java.util.Arrays;

import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.NfcA;
import android.nfc.tech.TagTechnology;
import android.util.Log;
import com.example.myapplication.util.MyNfcTag;

public class Activity_upload extends AppCompatActivity {

    TextView id;
    EditText bag_name;
    EditText draw_time;

    EditText material;

    Button   upload_btn;


    String _id;
    String _name;
    int  _time;
    String _material;

    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
        setId();


        upload_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                   addToken();
                }

        });
//
        if (isNFCReady()) {
            startActivity(new Intent(this, Activity_upload.class));
            findTag();
//            readNfcTag();
        }

    }

    public void setId() {
        id = findViewById(R.id.draw_id);
        bag_name = findViewById(R.id.draw_name);
        draw_time = findViewById(R.id.draw_time);
        material = findViewById(R.id.material);
        upload_btn = findViewById(R.id.upload_btn);

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

    }
    public void addToken(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                _id = id.getText().toString();
                _name = bag_name.getText().toString();
                _time = Integer.parseInt(draw_time.getText().toString());
                _material = material.getText().toString();
                try {
                    if(!MainActivity.token.getExist(_id).send()) {
                        TransactionReceipt hash = MainActivity.token.addToken(_id, _name, BigInteger.valueOf(_time),_material).send();
                        System.out.println(hash.getTransactionHash());


                        Activity_upload.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                new AlertDialog.Builder(Activity_upload.this)
                                        .setTitle("Transaction Success")
                                        .setMessage("交易Hash值為："+hash.getTransactionHash())
                                        .show();
                                id.setText("");
                                bag_name.setText("");
                                draw_time.setText("");
                                material.setText("");

                            }
                        });

                    }
                    else{

                        Activity_upload.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                new AlertDialog.Builder(Activity_upload.this)
                                        .setTitle("Error Message")
                                        .setMessage("該ID已經被註冊過！！！！")
                                        .show();
                            }
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    /*
     * 判斷裝置是否有支援/打開NFC功能
     */
    private boolean isNFCReady() {
        if (nfcAdapter == null) {
            Toast.makeText(this, "此裝置不支援NFC", Toast.LENGTH_LONG);
            return false;
        }
        if (nfcAdapter != null && !nfcAdapter.isEnabled()) {
            Toast.makeText(this, "請打開裝置的NFC功能", Toast.LENGTH_LONG);
            return false;
        }

        return true;
    }

    private void findTag() {
        Intent intent = getIntent();
        Log.e("Nfc",NfcAdapter.ACTION_TAG_DISCOVERED+" "+intent.getAction());
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction())) {
            Toast.makeText(this, "ACTION_TAG_DISCOVERED", Toast.LENGTH_SHORT).show();

            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);

            if (tag == null) {
//                tag_view.setText("沒有偵測到NFC Tag");
            } else {
                MyNfcTag myTag = new MyNfcTag(tag);
                id.setText(myTag.getTagid());
                Log.e("taginfo",myTag.getTagid());

//                tag_view.setText(myTag.getTagInfo());

            }
        } else {
            Toast.makeText(this, "ACTION_TAG_DISCOVERED NOT READY", Toast.LENGTH_SHORT).show();
        }

    }

    private void readNfcTag() {
        String ndefText = "";
        Intent intent = getIntent();
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);

        if (tag != null) {
            MyNfcTag myTag = new MyNfcTag(tag);
            TagTechnology object = myTag.getTagByFirstTech();

            if (object instanceof NfcA) {
                NfcA myNfcA = (NfcA) object;
                Toast.makeText(this, myNfcA.getMaxTransceiveLength() , Toast.LENGTH_SHORT).show();
//                ndef_view.setText("NfcA tag max transceive length is : " + myNfcA.getMaxTransceiveLength() + "\n");
            } else {
                Toast.makeText(this, "failed", Toast.LENGTH_SHORT).show();
//                ndef_view.setText("尚未實作相關讀取功能");
            }

        }


    }

    private String parseTextRecord(NdefRecord ndefRecord) {

        if (ndefRecord.getTnf() != NdefRecord.TNF_WELL_KNOWN) {
            return null;
        }

        if (!Arrays.equals(ndefRecord.getType(), NdefRecord.RTD_TEXT)) {
            return null;
        }

        try {

            byte[] payload = ndefRecord.getPayload();
            String textEncoding = ((payload[0] & 0x80) == 0) ? "UTF-8" : "UTF-16";

            int languageCodeLength = payload[0] & 0x3f;

            String languageCode = new String(payload, 1, languageCodeLength, "US-ASCII");
            String textRecord = new String(payload, languageCodeLength + 1, payload.length - languageCodeLength - 1, textEncoding);

            return textRecord;
        } catch (Exception e) {
            throw new IllegalArgumentException();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
        IntentFilter ndefDetected = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);

        try {
            ndefDetected.addDataType("text/plain");
        } catch (IntentFilter.MalformedMimeTypeException e) {
            Log.e(this.getClass().getName(), "MalformedMimeTypeException :" + e.getMessage());
        }
        // gNdefExchangeFilters = new IntentFilter[]{ ndefDetected };
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();

        if (nfcAdapter != null)
            nfcAdapter.disableForegroundDispatch(this);
    }


}
