package com.example.myapplication;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import org.web3j.tuples.generated.Tuple5;
import org.web3j.tuples.generated.Tuple7;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import jnr.ffi.Struct;

public class Activity_my extends AppCompatActivity {

    List arrayList = Collections.synchronizedList(new ArrayList());
    List info =new ArrayList();
    ListView list;
    Adapter_my adapter;
    String data[][];


    int count;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);
        info.clear();
        getalllist();
        list =  findViewById(R.id.listview);


    }

    public void getalllist(){
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                      count = Integer.parseInt(""+MainActivity.token.historyownerTokenCount(MainActivity.credentials.getAddress()).send());
                      System.out.println(count);
                        for(int i=0;i<count;i++) {
                            arrayList.add(MainActivity.token.allread(MainActivity.credentials.getAddress(), BigInteger.valueOf(i)).send());
                            if (!arrayList.get(i).equals("")) {
                                info.add(arrayList.get(i));
                                System.out.println(i+":"+info);

                            }
                        }

                        data=new String[info.size()][4];
                        System.out.println("長度"+data.length);

                        for(int i=0;i<info.size();i++){
                           Tuple5<String, String, String, BigInteger, String> A= MainActivity.token.getTokenInfo(info.get(i).toString()).send();
                            data[i][0]=A.getValue2(); //id
                            data[i][1]=A.getValue3(); //bag name
                            data[i][2]=A.getValue4().toString(); //time
                            data[i][3]=A.getValue5(); //材質


                        }
                        array(data);



                            Activity_my.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    list.setAdapter(adapter);

                                }
                            });




                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();


    }
    public void array(String A[][]){
        adapter = new Adapter_my(this.getLayoutInflater(),info,A);
    }
}
